using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CacheString : MonoBehaviour
{
    public static string TAG_LVBTN = "IdleLevelBtn";
    public static string TAG_Fade = "Fade";
}
